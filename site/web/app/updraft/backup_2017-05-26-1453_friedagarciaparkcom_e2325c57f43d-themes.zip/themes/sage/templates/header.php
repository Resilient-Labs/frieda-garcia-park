<header class="clearfix">
  <img src="logo.png" alt="ffgp"/>
  <nav class="nav-mobile clearfix">
    <?php wp_nav_menu(); ?>
  </nav>
</header>
