<header class="clearfix">
  <a href="http://frieda-garcia-park.dev"><img src="<?php bloginfo('template_directory');?>/assets/images/logo.png" alt="ffgp"/></a>
  <nav class="nav-mobile clearfix">
    <?php wp_nav_menu(); ?>
  </nav>
</header>
