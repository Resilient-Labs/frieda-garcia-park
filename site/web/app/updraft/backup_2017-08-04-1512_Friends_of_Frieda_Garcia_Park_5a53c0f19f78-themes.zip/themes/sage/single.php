<?php get_template_part('templates/content-single', get_post_type()); ?>
