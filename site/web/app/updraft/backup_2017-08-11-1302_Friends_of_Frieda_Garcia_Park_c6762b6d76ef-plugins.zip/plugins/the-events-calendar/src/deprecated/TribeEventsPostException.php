<?php
	_deprecated_file( __FILE__, '3.10', 'Tribe__Events__Post_Exception' );


	class TribeEventsPostException extends Tribe__Events__Post_Exception {

	}